import javax.swing.*;
import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class MyFavoriteVideoGame {
    private int currentLabel = 0;
    private ImageIcon[] myImages = new ImageIcon[6];
    private JLabel[] labels = new JLabel[6];

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> createAndShowGUI());
    }

    private void init() {
        myImages = new ImageIcon[6];
        // Load image files
        myImages[0] = new ImageIcon("/Users/zhouduanxi/Desktop/MyImage/1.jpeg");
        myImages[1] = new ImageIcon("/Users/zhouduanxi/Desktop/MyImage/2.jpeg");
        myImages[2] = new ImageIcon("/Users/zhouduanxi/Desktop/MyImage/3.jpeg");
        myImages[3] = new ImageIcon("/Users/zhouduanxi/Desktop/MyImage/4.jpeg");
        myImages[4] = new ImageIcon("/Users/zhouduanxi/Desktop/MyImage/5.jpeg");
        myImages[5] = new ImageIcon("/Users/zhouduanxi/Desktop/MyImage/6.jpeg");

        // Create JLabels
        for (int i = 0; i < labels.length; i++) {
            JLabel label = new JLabel(scaleImage(myImages[i], 1219, 324));
            labels[i] = label;
            label.setVisible(false);
        }
    }

    private static void createAndShowGUI() {
        MyFavoriteVideoGame demo = new MyFavoriteVideoGame();
        demo.init();

        // Create the main JFrame
        JFrame myFrame = new JFrame("My Favorite Video Games");
        myFrame.setMinimumSize(new Dimension(1219, 324));
        myFrame.setPreferredSize(new Dimension(1219, 324)); // Fix the semicolon error
        myFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        // Set up the main container with a BorderLayout
        Container container = myFrame.getContentPane();
        container.setLayout(new BorderLayout());

        // Create a panel to show my images
        JPanel topPanel = new JPanel(new GridLayout(3, 2));
        for (int i = 0; i < demo.labels.length; i++) {
            topPanel.add(demo.labels[i]);
        }
        demo.labels[demo.currentLabel].setVisible(true);
        container.add(topPanel, BorderLayout.CENTER);

        // Create a buttons to start
        JPanel btnPanel = new JPanel(new FlowLayout());
        JButton startBtn = new JButton("start");
        startBtn.addActionListener(e -> {
            demo.showNextLabel(topPanel);
        });
        btnPanel.add(startBtn);
        //Show all images
        JButton allBtn = new JButton("show all");
        allBtn.addActionListener(e -> {
            demo.showAllLabel(allBtn);
        });
        btnPanel.add(allBtn);
        container.add(btnPanel, BorderLayout.SOUTH);

        myFrame.pack();
        myFrame.setVisible(true);
    }

    private void showNextLabel(JPanel topPanel) {
        // Hide the current label and display the next one
        labels[currentLabel].setVisible(false);
        currentLabel = (currentLabel + 1) % labels.length;
        labels[currentLabel].setVisible(true);
    }

    private void showAllLabel(JButton btn) {
        if (btn.getText().equals("show all")) {
            // Show all image labels
            for (int i = 0; i < labels.length; i++) {
                labels[i].setVisible(true);
            }
            btn.setText("blank");
        } else {
            // Hide all image labels
            for (int i = 0; i < labels.length; i++) {
                labels[i].setVisible(false);
            }
            btn.setText("show all");
        }
    }

    private ImageIcon scaleImage(ImageIcon icon, int width, int height) {
        Image image = icon.getImage();
        Image scaledImage = image.getScaledInstance(icon.getIconWidth() / 2, icon.getIconHeight() / 2, Image.SCALE_SMOOTH);

        return new ImageIcon(scaledImage);
    }
}